/* const person = {
    firstName:'Muhammad',
    lastName:'Ibrahim',
    get fullName()
    {
        return `${person.firstName} ${person.lastName}`
    },
    set fullName(value)
    {
        const parts = value.split(' ');
        this.firstName = parts[0];
        this.lastName = parts[1]; 
    }
};

person.fullName = 'Bilal Sarwar';

console.log(person); */

// const numbers = [1, 2, -1, 3];

// const filtered = numbers.filter(n => n>=0)
//                         .map( n => ({value: n}) )
//                         .filter(obj => obj.value >1);

// console.log(filtered);



//Q1;

// const arr=[1,2,3,4];

// function swap (arr, i , j)
// {
//     let temp = arr[i];
//     arr[i] = arr[j];
//     arr[j] = temp;
// }

// function sort (arr) {
//     if(arr.length % 2 !== 0) {
//         console.log("The array has Odd indexes")
//     }
//     else {
//         for(let i=0; i<arr.length; i+=2) {
//             swap(arr, i, i+1);
//         }
//     }

//     return arr;
// }

// console.log(sort(arr));





//Q2

// function substrings(str1) {
//     var array1 = [];

//     for (var x = 0, y=1; x < str1.length; x++, y++) {
//       array1[x] = str1.substring(x, y);
//     }

//     var combi = [];
//     var temp = "";

//     var slent = Math.pow(2, array1.length);
    
//     for (var i = 0; i < slent ; i++) {
//       temp = "";

//       for (var j = 0; j < array1.length; j++) {
//         if ((i & Math.pow(2, j))) {
//           temp += array1[j];
//         }
//        }
      
//       if (temp !== "") {
//         combi.push(temp);
//         }
//     }
    
//     console.log(combi.join("\n"));
// }
  
// substrings("dog");






//Q3


// function uppercase(str)
// {
//   var array1 = str.split(' ');
//   var newarray1 = [];
    
//   for(var x = 0; x < array1.length; x++){
//       newarray1.push(array1[x].charAt(0).toUpperCase()+array1[x].slice(1));
//   }
//   return newarray1.join(' ');
// }
// console.log(uppercase("my name is ibrahim"));






//Q4

// function find_longest_word(str)
// {
//   var words = str.split(' ');

//   var longestWord = words.reduce(function(longest, currentWord) {
//     return currentWord.length > longest.length ? currentWord : longest;
//   }, "");

//   return longestWord;
// }

// console.log(find_longest_word('Saim stood up'));





//Q5


const str="mississippi"



function checkPalindrome(str) {
    const rev=str.split("").reverse().join("");
    return rev===str;
}

function longestPalindrome(words)
{
    var longestWord = words.reduce(function(longest, currentWord) {
        return currentWord.length > longest.length ? currentWord : longest;
    }, "");

    return longestWord;
}

function palindromeList(strr) {
    const str1=strr.split('');
    let combinations=[];
    let sample;
    for(let i= 0; i< str1.length; i++){
        //console.log(str1[i]);
        for(let j=i+1; j< str1.length; j++){
            //console.log(str1[j]);
            if(str1[i]===str1[j]){
                sample=[];
                for(let k= i; k<= j; k++){
                    sample.push(str1[k]);
                }
                sample = sample.join('');
                //console.log(sample);
                if(checkPalindrome(sample)){
                    combinations.push(sample);
                    //console.log(combinations);
                }
            }
        }
    }

    console.log(combinations);
    return longestPalindrome(combinations);
}

console.log(palindromeList(str));